# Quarto 中文书籍模板

一个可以直接渲染的简洁书籍骨架。示例章节展示正文、提示框、表格、交叉引用、公式、代码块和参考文献；所有示例内容都可以替换。

## 目录

```text
quarto-book-template/
├─ _quarto.yml          # 书籍信息、导航和 HTML 格式
├─ index.qmd            # 首页／前言
├─ chapters/            # 按阅读顺序编号的章节
├─ references.bib       # 文献条目
├─ styles.css           # 少量外观调整
└─ .github/workflows/   # 可选的 GitHub Pages 部署流程
```

## 开始写作

1. 复制此文件夹，修改 `_quarto.yml` 中的书名、副标题和作者。
2. 用自己的内容替换 `index.qmd` 和 `chapters/` 中的示例；新增或删除章节时，同步修改 `_quarto.yml` 的 `book.chapters`。
3. 图片等静态文件可放入新建的 `assets/` 文件夹，章节中用相对路径引用，例如 `![图注](../assets/figure.png)`。
4. 如需文献引用，在 `references.bib` 中增加条目，并在正文中写 `[@引用键]`。不需要参考文献时，可同时删去 `_quarto.yml` 中的 `bibliography` 和章节列表里的 `chapters/references.qmd`。

在本目录运行：

```bash
quarto preview
```

浏览器会打开本地预览。正式生成静态网站时运行：

```bash
quarto render
```

输出位于 `docs/`，该目录已被 Git 忽略。

## 发布到 GitHub Pages（可选）

模板中的工作流会在推送到 `main` 后构建并部署。将此文件夹作为仓库根目录使用，并在仓库的 **Settings → Pages → Build and deployment** 中选择 **GitHub Actions**。如果使用别的默认分支，请同步修改 `.github/workflows/build-book.yml`。

此模板使用纯文本示例，构建不需要 Python、R 或 Jupyter。若以后加入可执行代码，请自行安装对应运行环境，并按需要调整 `_quarto.yml` 的 `execute` 设置。
